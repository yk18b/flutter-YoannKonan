import 'dart:math';
import 'CaseModel.dart';
class MapModel{
  int nbLine = 0;
  int nbCol = 0;
  int nbBomb = 0;
  List<List<CaseModel>> _cases = List<List<CaseModel>>.empty();

  initCases(){
    _cases = List<List<CaseModel>>.generate(
        nbLine, (i) => List<CaseModel>.generate(nbCol,(j)
    => CaseModel()
    ));
  }
  initBomb() {
    int bombe = 0;
    Random random = Random();

    // Placer les bombes de manière aléatoire dans les cases
    while (bombe < nbBomb) {
      // Choisir des indices aléatoires pour la position de la bombe
      int x = random.nextInt(nbLine);
      int y = random.nextInt(nbCol);

      // Vérifier si une bombe est déjà placée dans la case (x, y)
      if (!_cases[x][y].hasBomb) {
        _cases[x][y].setBomb(true); // Marquer la case comme ayant une bombe
        bombe++; // Incrémenter le compteur de bombes
      }
    }
  }

  }
  initNumbers(){
    int x = Random().nextInt(maxInt);
    _cases = List<List<CaseModel>>.generate(
        nbLine, (x) => List<CaseModel>.generate(nbCol,(x)
    => CaseModel()
    ));
  }
}