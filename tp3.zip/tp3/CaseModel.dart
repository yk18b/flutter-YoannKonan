class CaseModel{
   bool? hidden;
   bool? hasBomb;
   bool? hasExploded;
   bool? hasFlag;
   int? number;
   
   // Constructeur
   MapModel(this.nbLine, this.nbCol, this.nbBomb) {
     initCases();
   }
}